<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CustomerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- resources/views/cart/detail-list.blade.php -->

    <div class="container my-4">
        <div class="row justify-content-between">
            <div class="col-md-8 text-left">
                <h2 class="d-inline-block">Cart Detail List</h2>
            </div>

            <div class="col-md-2 text-right">
                <a href="<?php echo e(route('menu.index', ['restaurant' => $reservation->restaurant->id, 'reservation' => $reservation->id])); ?>"
                    class="btn btn-primary ml-auto w-100">Add More</a>
            </div>
        </div>

        <div class="row mt-3 mb-5">
            <div class="col-md-12">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Number</th>
                            <th>Menu Image</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!count($cart_details) == 0): ?>
                            <?php $__currentLoopData = $cart_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><img src="<?php echo e(Storage::url($item->menu->image)); ?>" width="200px"></td>
                                    <td><?php echo e($item->menu->name); ?></td>
                                    <td><?php echo e('Rp ' . number_format($item->menu->price, 0, ',', '.')); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e('Rp ' . number_format($item->subtotal, 0, ',', '.')); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('cart.list.detail.update', ['menu' => $item->menu->id, 'reservation' => $reservation->id, 'cart_detail' => $item->id])); ?>"
                                            class="btn btn-warning">Edit</a>
                                        <form
                                            action="<?php echo e(route('cart.list.detail.delete', ['reservation' => $reservation->id, 'cart_detail' => $item->id])); ?>"
                                            method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="5" class="text-right font-weight-bold">Total Payment:</td>
                                <td colspan="2" class="font-weight-bold">
                                    <?php echo e('Rp ' . number_format($cart_header->total, 0, ',', '.')); ?></td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-right font-weight-bold">There is no item in the cart
                                    please add item first</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row justify-content-between mt-5" style="margin-top:300px;margin-">
            <div class="col-md-8 text-left">
                <h5 class="d-inline-block">* Please make sure to upload the receipt in the Reservation List page</h5>
            </div>

            <div class="col-md-2 text-right">
                <form action="<?php echo e(route('cart.list.confirm', $reservation->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <button type="submit" class="btn btn-success ml-auto w-100">Confirm Transaction</button>
                </form>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/customer/cart/cart-detail-list.blade.php ENDPATH**/ ?>