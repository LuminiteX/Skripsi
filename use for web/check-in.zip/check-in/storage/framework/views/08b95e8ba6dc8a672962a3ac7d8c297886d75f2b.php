<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>

</svg>
<?php /**PATH E:\Binus\Skripsi\Code\check-in\resources\views/components/application-logo.blade.php ENDPATH**/ ?>