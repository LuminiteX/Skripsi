<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CustomerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div class="col-md-12 mb-5 ">
        <h5 class="fw-bold mb-3 px-5">Category</h5>
        <div class="row row-cols-1 row-cols-md-3 g-3 px-5">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card h-100">
                        <div class="row g-0">
                            <div class="col-md-4 p-2 align-items-center">
                                <img src="<?php echo e(Storage::url($category->image)); ?>"
                                    class="img-fluid rounded-start mx-auto d-block" alt="<?php echo e($category->name); ?>"
                                    style="max-height: 200px;">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body" style="height: 150px; overflow-y: auto;">
                                    <h5 class="card-title"><?php echo e($category->name); ?></h5>
                                    <p class="card-text" style="overflow-wrap: break-word;"><?php echo e($category->description); ?>

                                    </p>
                                </div>
                                <div class="card-footer d-flex justify-content-start"
                                    style="background-color: rgba(0,0,0,0) !important; border-top: none !important">
                                    <a href="<?php echo e(route('menu.sort.by', ['category' => $category->id, 'reservation' => $reservation->id])); ?>"
                                        class="btn btn-sm btn-primary">View Menu</a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-center mt-3">
            <?php echo e($categories->links('pagination::bootstrap-5')); ?>

        </div>
    </div>
    <h2 class="my-4 mx-md-5 mx-xl-5 bottom-2">Menu</h2>
    <div class="container-fluid px-5 py-6 mx-auto mb-5">
        <div class="row row-cols-1 row-cols-lg-3 g-4">
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card h-100">
                        <img src="<?php echo e(Storage::url($menu->image)); ?>" alt="Image"
                            class="card-img-top h-50 object-fit-cover">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($menu->name); ?></h5>
                            <p class="card-text">
                                <?php echo e(\Illuminate\Support\Str::limit($menu->description, 200, $end = '...')); ?></p>

                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center">
                            <span
                                class="text-success font-weight-bold"><?php echo e('Rp ' . number_format($menu->price, 0, ',', '.')); ?></span>
                            <a href="<?php echo e(route('menu.detail', ['menu' => $menu->id, 'reservation' => $reservation->id])); ?>"
                                class="btn btn-sm btn-primary">View
                                Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-center mt-5 mb-3">
            <a href="<?php echo e(route('cart.list.detail', ['reservation' => $reservation->id])); ?>"
                class="btn btn-lg btn-warning">Manage Cart
                Details</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/customer/menus/index.blade.php ENDPATH**/ ?>