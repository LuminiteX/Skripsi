<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CustomerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container mt-0">
        <div class="row justify-content-center mt-0">
            <div class="col-12 col-xxl-8 mt-0">
                <a href="<?php echo e(route('menu.index', ['restaurant' => $reservation->restaurant->id, 'reservation' => $reservation->id])); ?>"
                    class="btn btn-sm btn-primary mt-5 mb-5">Return
                    Back
                    to
                    menu</a>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-xxl-8 mt-2 mb-5">
                <div class="card">
                    <div class="card-header text-center fs-3 fw-bold"><?php echo e($menu->name); ?></div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 d-flex justify-content-center">
                                <img src="<?php echo e(Storage::url($menu->image)); ?>" alt="<?php echo e($menu->name); ?>" class="img-fluid">
                            </div>
                            <div class="col-md-6">
                                <p><?php echo e($menu->description); ?></p>
                                <p>Category: <?php echo e($categories->name); ?></p>
                                <p>Price: <?php echo e('Rp ' . number_format($menu->price, 0, ',', '.')); ?></p>
                                
                                <form method="POST"
                                    action="<?php echo e(route('cart.store', ['restaurant' => $reservation->restaurant->id, 'reservation' => $reservation->id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row">
                                        <input type="hidden" name="menu_id" value="<?php echo e($menu->id); ?>">
                                        <label for="qty" class="col-md-2 col-form-label">Qty</label>
                                        <div class="col-lg-6 col-md-8">
                                            <input type="number" class="form-control" id="qty" name="qty">
                                        </div>
                                        <div class="col-lg-4 col-md-8 mt-sm-2 mt-lg-0">
                                            <button type="submit" class="btn btn-primary">Add to Cart</button>
                                        </div>
                                        <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-sm text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/customer/menus/menu-detail.blade.php ENDPATH**/ ?>