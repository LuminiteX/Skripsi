<?php if (isset($component)) { $__componentOriginalf5186ab1aeb2ab3e6b6942e3af00cfc5a7e4976e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OwnerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('owner-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OwnerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php if(auth()->user()->has_restaurant == 1): ?>
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="m-2 p-2 bg-slate-100 rounded">
                    <div class="space-y-8 divide-y divide-gray-200 mt-10 mx-1">
                        <div class="container mx-auto lg:flex lg:flex-row">
                            <div class="w-full lg:w-1/2 flex items-center justify-center mb-10">
                                <?php if($restaurant->image): ?>
                                    <div class="w-full h-64 px-4">
                                        <img class="object-cover w-full h-full"
                                            src="<?php echo e(Storage::url($restaurant->image)); ?>" alt="Restaurant image">
                                    </div>
                                <?php else: ?>
                                    <img class="max-h-64" src="<?php echo e(asset('storage/default/default-image.jpg')); ?>"
                                        alt="Default image">
                                <?php endif; ?>
                            </div>
                            <div class="w-full lg:w-1/2 lg:ml-5 px-2">
                                <h2 class="text-xl font-bold mb-2 border-b-2 border-gray-200 pb-2">
                                    Restaurant Name
                                </h2>
                                <p class="text-gray-600 mb-2">
                                    <?php echo e($restaurant->name); ?>

                                </p>
                                <h2 class="text-xl font-bold mb-2 border-b-2 border-gray-200 pb-2">
                                    Restaurant Description
                                </h2>
                                <p class="text-gray-600 mb-2">
                                    <?php echo e($restaurant->description); ?>

                                </p>
                                <h2 class="text-xl font-bold mb-2 border-b-2 border-gray-200 pb-2">
                                    Restaurant Phone Number
                                </h2>
                                <p class="text-gray-600 mb-2">
                                    <?php echo e($restaurant->phone_number); ?>

                                </p>
                                <h2 class="text-xl font-bold mb-2 border-b-2 border-gray-200 pb-2">
                                    Restaurant Address
                                </h2>
                                <p class="text-gray-600 mb-2">
                                    <?php echo e($restaurant->address); ?>

                                </p>
                                <h2 class="text-xl font-bold mb-2 border-b-2 border-gray-200 pb-2">
                                    Restaurant Opening Time
                                </h2>
                                <p class="text-gray-600 mb-2">
                                    Opening Time:
                                    <?php echo e($formattedTimeOpening); ?>

                                </p>
                                <h2 class="text-xl font-bold mb-2 border-b-2 border-gray-200 pb-2">
                                    Restaurant Closing Time
                                </h2>
                                <p class="text-gray-600 mb-2">
                                    Closing Time: <?php echo e($formattedTimeClosing); ?>

                                </p>
                                <h2 class="text-xl font-bold mb-2 border-b-2 border-gray-200 pb-2">
                                    Restaurant Status
                                </h2>
                                <p class="text-gray-600 mb-2">Status:
                                    <?php if($restaurant->restaurant_status == 0): ?>
                                        Not eligible
                                    <?php endif; ?>
                                    <?php if($restaurant->restaurant_status == 1): ?>
                                        Eligible
                                    <?php endif; ?>
                                </p>
                                <h2 class="text-xl font-bold mb-2 border-b-2 border-gray-200 pb-2">
                                    Restaurant Opening Status
                                </h2>
                                <p class="text-gray-600 mb-2">Opening Status:
                                    <?php if($restaurant->restaurant_opening_status == 0): ?>
                                        Closed
                                    <?php endif; ?>
                                    <?php if($restaurant->restaurant_opening_status == 1): ?>
                                        Open
                                    <?php endif; ?>
                                </p>
                                <div class="flex sm:justify-center md:justify-start mt-8 space-x-10">
                                    
                                    <a href="<?php echo e(route('owner.restaurant.profile.activate')); ?>"
                                        class="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded s">Open</a>
                                    <a href="<?php echo e(route('owner.restaurant.profile.deactivate')); ?>"
                                        class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded">Close</a>
                                    <a href="<?php echo e(route('owner.restaurant.profile.edit.show')); ?>"
                                        class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded">Edit</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf5186ab1aeb2ab3e6b6942e3af00cfc5a7e4976e)): ?>
<?php $component = $__componentOriginalf5186ab1aeb2ab3e6b6942e3af00cfc5a7e4976e; ?>
<?php unset($__componentOriginalf5186ab1aeb2ab3e6b6942e3af00cfc5a7e4976e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/owner/restaurant/profile.blade.php ENDPATH**/ ?>