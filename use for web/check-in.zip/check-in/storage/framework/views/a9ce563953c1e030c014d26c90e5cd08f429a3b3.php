<?php if (isset($component)) { $__componentOriginalf5186ab1aeb2ab3e6b6942e3af00cfc5a7e4976e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OwnerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('owner-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OwnerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    You're logged in!
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf5186ab1aeb2ab3e6b6942e3af00cfc5a7e4976e)): ?>
<?php $component = $__componentOriginalf5186ab1aeb2ab3e6b6942e3af00cfc5a7e4976e; ?>
<?php unset($__componentOriginalf5186ab1aeb2ab3e6b6942e3af00cfc5a7e4976e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/owner/index.blade.php ENDPATH**/ ?>