<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CustomerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <?php if(session('message')): ?>
            <div class="alert alert-info mt-2"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-6 offset-md-3 mt-4">
                <form action="<?php echo e(route('restaurants.search')); ?>" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="Search for restaurants..."
                            value="<?php echo e(Request::get('search')); ?>">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">
                                <i class="fa fa-search"></i> Search
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row mt-4">
            <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($index % 3 == 0 && $index != 0): ?>
        </div>
        <div class="row mt-4">
            <?php endif; ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?php echo e(Storage::url($restaurant->image)); ?>" class="card-img-top" alt="<?php echo e($restaurant->name); ?>"
                        style="max-height: 150px;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($restaurant->name); ?></h5>
                        <p class="card-text">Restaurant Address: <?php echo e($restaurant->address); ?></p>
                        <p class="card-text">
                            Rating:
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <?php if($i <= $restaurant->rating): ?>
                                    <i class="fas fa-star text-warning" style="color: gold;"></i>
                                <?php elseif($i == ceil($restaurant->rating)): ?>
                                    <i class="fas fa-star-half-alt text-warning" style="color: gold;"></i>
                                <?php else: ?>
                                    <i class="far fa-star text-warning" style="color: gold;"></i>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </p>
                        <p class="card-text">Views: <?php echo e($restaurant->view); ?></p>
                        <a href="<?php echo e(route('restaurants.details', $restaurant->id)); ?>" class="btn btn-primary">View
                            Restaurant</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row">
            <div class="col-md-12 d-flex justify-content-center">
                <?php echo e($restaurants->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/customer/reservation/index.blade.php ENDPATH**/ ?>