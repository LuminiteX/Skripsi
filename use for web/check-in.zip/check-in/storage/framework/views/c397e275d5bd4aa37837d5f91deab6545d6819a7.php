<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CustomerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container bg-white text-body">
        <div class="row mb-3 mt-3">
            <h2>Cart List</h2>
            <hr class="border-dark" style="width: 25%">
        </div>
        <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="container d-flex align-items-center">
                <div class="row text-white mt-2 rounded" style="background-color: rgba(0, 0, 0, 0.5)">
                    <div class="col mt-2 mb-2">
                        <img src="<?php echo e(Storage::url($reservation->restaurant->image)); ?>" class="img-fluid">
                    </div>
                    <div class="col mt-2 mb-2">
                        <div class="row text-white">
                            <h3><?php echo e($reservation->restaurant->name); ?></h3>
                            <p><?php echo e($reservation->restaurant->address); ?></p>
                            <hr class="border-dark">
                            <p>Reservation Date : <?php echo e($reservation->reservation_date); ?></p>
                            <p>Guest Number : <?php echo e($reservation->guest_number); ?></p>
                            <p>Table : <?php echo e($reservation->table->name); ?></p>
                            <p class="mt-3"> Created At : <?php echo e($reservation->created_at); ?></p>
                        </div>
                    </div>
                    <div class="col mt-4">
                        <div class="d-flex justify-content-center mt-5">
                            <a href="<?php echo e(route('cart.list.detail', ['reservation' => $reservation->id])); ?>"
                                class="btn btn-lg btn-primary">Manage Cart Detail</a>
                        </div>
                        <div class="d-flex justify-content-center mt-5">
                            <form action="<?php echo e(route('cart.cancel', $reservation->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <button type="submit" class="btn btn-lg btn-danger">Cancel Reservation</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex justify-content-center mt-3">
            <?php echo e($reservations->links('pagination::bootstrap-5')); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/customer/cart/cart-list.blade.php ENDPATH**/ ?>