<?php if (isset($component)) { $__componentOriginald5a7f66e2ce3041164c4f126e13db13bac71df97 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MemberLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('member-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\MemberLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <p class="text-center">Center aligned text on all viewport sizes.</p>

    <button type="button" class="btn btn-primary">Primary</button>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5a7f66e2ce3041164c4f126e13db13bac71df97)): ?>
<?php $component = $__componentOriginald5a7f66e2ce3041164c4f126e13db13bac71df97; ?>
<?php unset($__componentOriginald5a7f66e2ce3041164c4f126e13db13bac71df97); ?>
<?php endif; ?>
<?php /**PATH E:\Binus\Skripsi\Code\check-in\resources\views/testing.blade.php ENDPATH**/ ?>