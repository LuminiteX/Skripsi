<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CustomerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12" style="padding: 0;">
                <img src="<?php echo e(Storage::url($restaurants->image)); ?>" class="img-fluid"
                    style="width: 100%; height: 300px; object-fit: cover;">
            </div>
        </div>
        <div class="col-md-12 mt-3">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h2 class="fw-bold mb-0"><?php echo e($restaurants->name); ?></h2>
                </div>
                <div class="col-md-6 d-flex justify-content-end align-items-center mt-sm-2 mt-xs-2">
                    <a href="<?php echo e(route('reservations.step.one', $restaurants->id)); ?>"
                        class="btn btn-primary me-3">Reserve
                        Now</a>
                    <div class="rating-section me-2 me-md-3">
                        <p class="card-text mb-0"">
                            Rating:
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <?php if($i <= $restaurants->rating): ?>
                                    <i class="fas fa-star text-warning" style="color: gold;"></i>
                                <?php elseif($i == ceil($restaurants->rating)): ?>
                                    <i class="fas fa-star-half-alt text-warning" style="color: gold;"></i>
                                <?php else: ?>
                                    <i class="far fa-star text-warning" style="color: gold;"></i>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </p>
                    </div>
                    <div class="views-section ms-md-3">
                        <i class="fas fa-eye me-1"></i>
                        <span><?php echo e($restaurants->view); ?> views</span>
                    </div>
                </div>
            </div>
            <hr>
        </div>

        <div class="col-md-12 mt-2">
            <h5 class="fw-bold mb-0">Opening Time</h5>
            <p class="mb-4 mt-2 fs-6"> Restaurant Opens at <strong><?php echo e($formattedTimeOpening); ?> -
                    <?php echo e($formattedTimeClosing); ?></strong></p>

        </div>

        <div class="col-md-12 mt-2">
            <h5 class="fw-bold mb-0">Description </h5>
            <p class="mb-4 mt-2"><?php echo e($restaurants->description); ?></p>
            <div class="mb-4">
                <h5 class="fw-bold mb-3">Contact Us</h5>
                <p>Phone: <?php echo e($restaurants->phone_number); ?></p>
                <p>Email: <?php echo e($restaurants->user->email); ?></p>
            </div>
            <h5 class="fw-bold mb-3">Address</h5>
            <p><?php echo e($restaurants->address); ?></p>
        </div>
        <div class="col-md-12 row mt-5">
            <div class="col-md-12 mb-2">
                <h5 class="fw-bold mb-3">Menu</h5>
                <div class="row row-cols-1 row-cols-md-3 g-3">
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="card h-100">
                                <div class="row g-0 align-items-center">
                                    <div class="col-md-4 p-2">
                                        <img src="<?php echo e(Storage::url($menu->image)); ?>"
                                            class="img-fluid rounded-start mx-auto d-block" alt="<?php echo e($menu->name); ?>"
                                            style="max-height: 200px;">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body" style="height: 200px; overflow-y: auto;">
                                            <h5 class="card-title"><?php echo e($menu->name); ?></h5>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <?php if($menu->chef_recommendation): ?>
                                                    <span class="badge bg-warning text-dark">Chef Recommendation</span>
                                                <?php endif; ?>
                                            </div>
                                            <p class="card-text" style="overflow-wrap: break-word;">
                                                <?php echo e($menu->description); ?>

                                            </p>
                                        </div>
                                        <div class="card-footer d-flex justify-content-start"
                                            style="background-color: rgba(0,0,0,0) !important; border-top: none !important">
                                            <p class="card-text">
                                                <small class="text-muted">Price =
                                                    <?php echo e('Rp ' . number_format($menu->price, 0, ',', '.')); ?></small>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="d-flex justify-content-center mt-3">
                    <?php echo e($menus->links('pagination::bootstrap-5')); ?>

                </div>
            </div>
            <div class="col-md-12 row mt-5">
                <div class="col-md-12">
                    <h5 class="fw-bold mb-3">Graph</h5>
                    <div id="chart3"></div>
                </div>
            </div>
            <div class="col-md-12 row mt-5">
                <div class="col-md-12">
                    <h5 class="fw-bold mb-3">Comment</h5>
                    <div class="container py-5">
                        <div class="card">
                            <div class="card-body">
                                <h2 class="card-title mb-4">Comment Section</h2>
                                <div class="mb-5">
                                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="w-96 mb-4">
                                                <div class="d-flex mb-2">
                                                        <img src="<?php echo e(Storage::url($comment->user->image)); ?>" alt="User"
                                                            class="rounded-circle me-2 border" style="width: 50px; height: 50px;">
                                                    <div class="d-flex align-items-center mb-1">
                                                            <h5 class="mb-0 me-2"><?php echo e($comment->user->name); ?></h5>
                                                            <small
                                                                class="text-muted"><?php echo e($comment->created_at->diffForHumans()); ?></small>
                                                    </div>
                                                </div>
                                                <p class="mb-0"><?php echo e($comment->comment); ?></p>
                                                <div class="d-flex align-items-center mt-3">
                                                    <?php if($comment->user->id == auth()->user()->id): ?>
                                                        <form
                                                            action="<?php echo e(route('customer.comments.reply.destroy', ['comments' => $comment->id])); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit"
                                                                class="btn btn-danger me-2">Delete</button>
                                                        </form>
                                                    <?php endif; ?>
                                                    <button type="button" class="btn btn-primary me-2"
                                                        onclick="toggleCommentForm(<?php echo e($comment->id); ?>)">Reply</button>
                                                </div>
                                                <div class="d-none" id="comment-form-<?php echo e($comment->id); ?>">
                                                    <form
                                                        action="<?php echo e(route('customer.comments.reply', $restaurants->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="comment_id"
                                                            value="<?php echo e($comment->id); ?>">
                                                        <div class="d-flex align-items-end mb-3 mt-3">
                                                            <div class="flex-grow-1 me-3">
                                                                <textarea name="comment" class="form-control" placeholder="Leave a comment" style="height: 100px;"></textarea>
                                                            </div>
                                                            <button type="submit"
                                                                class="btn btn-primary">Submit</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <?php $__currentLoopData = $comment->child()->orderBy('created_at', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="d-flex mb-2 ms-5">
                                                <img src="<?php echo e(Storage::url($child->user->image)); ?>" alt="User"
                                                    class="rounded-circle me-2 border"
                                                    style="width: 50px; height: 50px;">
                                                <div>
                                                    <div class="d-flex align-items-center mb-1">
                                                        <h5 class="mb-0 me-2"><?php echo e($child->user->name); ?></h5>
                                                        <small class="text-muted">5 minutes ago</small>
                                                    </div>
                                                    <p class="mb-0"><?php echo e($child->comment); ?></p>
                                                    <?php if($child->user->id == auth()->user()->id): ?>
                                                        <form
                                                            action="<?php echo e(route('customer.comments.reply.destroy', ['comments' => $child->id])); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit"
                                                                class="btn btn-danger mt-2">Delete</button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <form action="<?php echo e(route('customer.comments.send', $restaurants->id)); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-floating mb-3">
                                        <textarea name="comment" class="form-control" placeholder="Leave a comment" style="height: 100px;"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleCommentForm(commentId) {
            var commentForm = document.getElementById('comment-form-' + commentId);
            if (commentForm.classList.contains('d-none')) {
                commentForm.classList.remove('d-none');
            } else {
                commentForm.classList.add('d-none');
            }
        }
    </script>


    <script>
        var chartData3 = <?php echo json_encode($chartData3); ?>;

        Highcharts.chart('chart3', {
            chart: {
                type: 'area'
            },
            title: {
                text: 'The amount of reservation in <?php echo $restaurants->name; ?>'
            },
            xAxis: {
                categories: chartData3.categories,
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Reservation'
                }
            },

            series: [{
                name: 'Reservations',
                data: chartData3.data

            }]
        }, function(chart3) { // callback function to customize legend
            var legendItems = chart.legend.allItems;
            for (var i = 0; i < legendItems.length; i++) {
                legendItems[i].color = chart2.series[0].color;
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/customer/reservation/restaurant.blade.php ENDPATH**/ ?>