<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CustomerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container bg-white text-body">
        <div class="row mb-3 mt-3">
            <div class="col-lg-10 text-left">
                <h2>Reservation List</h2>
                <hr class="border-dark" style="width: 50%">
            </div>
            <div class="col-md-2 d-flex justify-content-end mt-2" style="height:50%">
                <a href="<?php echo e(route('reservations.history')); ?>" class="btn btn-primary">View
                    History</a>
            </div>
        </div>
        <?php if(!count($reservations) == 0): ?>
            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="container d-flex align-items-center">
                    <div class="row text-white mt-2 rounded" style="background-color: rgba(0, 0, 0, 0.5)">
                        <div class="col mt-2 mb-2">
                            <img src="<?php echo e(Storage::url($reservation->restaurant->image)); ?>" class="img-fluid">
                        </div>
                        <div class="col mt-2 mb-2">
                            <div class="row text-white">
                                <h3><?php echo e($reservation->restaurant->name); ?></h3>
                                <p><?php echo e($reservation->restaurant->address); ?></p>
                                <hr class="border-dark">
                                <p>Reservation Date : <?php echo e($reservation->reservation_date); ?></p>
                                <p>Guest Number : <?php echo e($reservation->guest_number); ?></p>
                                <p>Table : <?php echo e($reservation->table->name); ?></p>
                                <p> Created At : <?php echo e($reservation->created_at); ?></p>
                                <b>Reservation with menu: <?php if($reservation->cart_header): ?>
                                        Yes
                                    <?php else: ?>
                                        No
                                    <?php endif; ?> </b>
                                <b>Reservation Status: <?php if($reservation->reservation_status == 1): ?>
                                        Receipt not uploaded
                                    <?php elseif($reservation->reservation_status == 2): ?>
                                        Reservation being checked
                                    <?php else: ?>
                                        Reservation eligible
                                    <?php endif; ?>
                                </b>
                            </div>
                        </div>
                        <div class="col mt-4 justify-content-center align-items-center">
                            <?php if($reservation->reservation_status == 1): ?>
                                <div class="d-flex justify-content-center mt-5">
                                    <a href="<?php echo e(route('reservations.detail.upload.receipt', $reservation->id)); ?>"
                                        class="btn btn-lg btn-primary" style="width: 199px">Upload Receipt</a>
                                </div>
                                <div class="d-flex justify-content-center mt-5">
                                    <form action="<?php echo e(route('reservations.list.cancel', $reservation->id)); ?>"
                                        method="POST"
                                        onsubmit="return confirm('Are you sure you want to cancel this reservation?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button type="submit" class="btn btn-lg btn-danger">Cancel Reservation</button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <?php if($reservation->cart_header): ?>
                                    <div class="d-flex justify-content-center mt-5"></div>
                                    <div class="d-flex justify-content-center mt-5">
                                        <a href="<?php echo e(route('reservations.detail.with.menu', $reservation->id)); ?>"
                                            class="btn btn-lg btn-danger">View Reservation</a>
                                    </div>
                                <?php else: ?>
                                    <div class="d-flex justify-content-center mt-5"></div>
                                    <div class="d-flex justify-content-center mt-5">
                                        <a href="<?php echo e(route('reservations.detail.without.menu', $reservation->id)); ?>"
                                            class="btn btn-lg btn-danger">View Reservation</a>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex justify-content-center mt-3">
                <?php echo e($reservations->links('pagination::bootstrap-5')); ?>

            </div>
        <?php else: ?>
            <h3 class="mb-0 text-md"> <i class="fas fa-info-circle mr-2" style="color:grey;"></i> No reservations yet
            </h3>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/customer/reservation/reservation-list.blade.php ENDPATH**/ ?>