<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CustomerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid flex-grow-1 p-0">
        <div class="card text-white ">
            <img src="storage/HomeImg/HomeBanner.jpg" alt="Top Picture" class="img-fluid" style="max-height: 300px; object-fit: cover;">
            <div class="card-img-overlay text-center mt-5">
                <h3 class="card-title mt-4">Welcome to Check-In!</h3>
                <p class="card-text mt-4 mb-4">Check-In is a web based application that aims to help you make
                    reservations in restaurants that you want! With Check-In, it's going to be easier to make
                    reservations!</p>
                <a href="<?php echo e(route('restaurants.list')); ?>" class="btn btn-primary">Make your reservation</a>
            </div>
        </div>
        <div class="container bg-white text-body pt-5">
            <div class="row">
                <div class="col mt-5">
                    <h5 class="mt-5">OUR STORY</h5>
                    <h2>Welcome</h2>
                    <h5>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Temporibus nemo incidunt praesentium, ipsum culpa
                        minus eveniet, id nesciunt excepturi sit voluptate
                        repudiandae. Explicabo, incidunt quia. Repellendus
                        mollitia quaerat est voluptas!</h5>
                </div>
                <div class="col mb-5">
                    <img src="storage/HomeImg/Food.jpeg" alt="Food" class="img-fluid" style="max-width: 500px;">
                </div>
            </div>
        </div>
        <div class="container bg-secondary text-white">
            <div class="row">
                <div class="col mt-5">
                    <h5 class="mt-5">About Us</h5>
                    <h1>WHY CHOOSE US?</h1>
                    <h5>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Temporibus nemo incidunt praesentium, ipsum culpa
                        minus eveniet, id nesciunt excepturi sit voluptate
                        repudiandae. Explicabo, incidunt quia. Repellendus
                        mollitia quaerat est voluptas!</h5>
                    <div class="row mt-4">
                        <div class="col-sm-1 text-info">
                            <h5>1.</h5>
                        </div>
                        <div class="col align-self-center">
                            <h5> Easy and Quick Reservation and Menu Ordering</h5>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-sm-1 text-info">
                            <h5>2.</h5>
                        </div>
                        <div class="col align-self-center">
                            <h5> Multiple Restaurant Choices</h5>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-sm-1 text-info">
                            <h5>3.</h5>
                        </div>
                        <div class="col align-self-center">
                            <h5> Minimal Physical Contact Needed</h5>
                        </div>
                    </div>
                </div>
                <div class="col mt-5 mb-5">
                    <img src="storage/HomeImg/choose.jpg" alt="choose" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/customer/home.blade.php ENDPATH**/ ?>