<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Check-In</title>


    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">


    <!-- Styles -->
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css"
        integrity="sha512-..." crossorigin="anonymous" />


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-+8twhnV7X9y+CXEob2xl3e5YiQ2CBtcE5GrzAr5pHlG09El+F7X9avtRpDIfxOrL" crossorigin="anonymous">
    </script>

    <link rel="icon" type="image/png" href="<?php echo e(asset('storage/logo/logo.png')); ?>">
    <!-- Scripts -->
    
    

    



    <link rel="icon" type="image/png" href="<?php echo e(asset('storage/logo/logo.png')); ?>">

    <script src="https://kit.fontawesome.com/b63c8b9802.js" crossorigin="anonymous"></script>

    
    <script src="<?php echo e(asset('js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</head>
<header>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="<?php echo e(asset('storage/logo/logo.png')); ?>" alt="" width="150" height="100">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item mx-3 ml-2">
                        <a class="nav-link" aria-current="page" href="/">Home</a>
                    </li>
                    <li class="nav-item mx-3 ml-2">
                        <a class="nav-link" href="<?php echo e(route('restaurants.list')); ?>">Make Reservation</a>
                    </li>
                    <li class="nav-item mx-3 ml-2">
                        <a class="nav-link" href="<?php echo e(route('reservations.list')); ?>">Reservation List</a>
                    </li>
                    <li class="nav-item mx-3 ml-2">
                        <a class="nav-link" href="<?php echo e(route('cart.list')); ?>">Manage Cart</a>
                    </li>
                    <li class="nav-item mx-3 ml-2">
                        <a class="nav-link" href="<?php echo e(route('customer.show.profile')); ?>">Profile</a>
                    </li>
                    <li class="nav-item mx-3 ml-2">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            Log Out
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>



<body class="d-flex flex-column min-vh-100">
    
    <?php echo e($slot); ?>

</body>

<footer class="bg-light py-3 mt-auto">
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/layouts/customer.blade.php ENDPATH**/ ?>