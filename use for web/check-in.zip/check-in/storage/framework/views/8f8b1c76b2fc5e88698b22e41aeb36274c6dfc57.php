<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CustomerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger mt-2 mb-2"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if($restaurant->tableLayout): ?>
        <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php $__currentLoopData = $restaurant->tableLayout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item<?php echo e($loop->first ? ' active' : ''); ?>">
                        <img src="<?php echo e(Storage::url($item->floor_image)); ?>" class="d-block w-100 bg-dark"
                            style="height:600px;object-fit: contain;" alt="<?php echo e($item->floor_name); ?>">
                        <div
                            class="carousel-caption"style="background-color: rgba(0, 0, 0, 0.5); position: absolute; bottom: 0; left: 0; right: 0;">
                            <h5>Floor number <?php echo e($item->floor_number); ?></h5>
                            <p><?php echo e($item->floor_name); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    <?php endif; ?>



    <div class="container py-5">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-9 mb-4 mb-md-10 col-lg-6">
                <img class="object-cover" src="https://cdn.pixabay.com/photo/2021/01/15/17/01/green-5919790__340.jpg"
                    alt="img" />
            </div>
            <div class="col-md-12 col-lg-6">
                <div class="card shadow">
                    <div class="card-body">
                        <h3 class="card-title text-primary mb-4">Make Reservation</h3>
                        <ul class="nav nav-pills mb-4" id="pills-tab" role="tablist">
                            <li class="nav-item w-100" role="presentation">
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 100%;"
                                        aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">Step 2</div>
                                </div>
                            </li>
                        </ul>

                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-step1" role="tabpanel"
                                aria-labelledby="pills-step1-tab">
                                <form id="myForm" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-sm-6 pt-2">
                                        <label for="status"
                                            class="form-label font-weight-bold text-gray-700">Table</label>
                                        <div class="mb-3">
                                            <select id="table_id" name="table_id" class="form-select form-control"
                                                style="width: 400px;">
                                                <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($table->id); ?>" <?php if($table->id == $reservation->table_id): echo 'selected'; endif; ?>>
                                                        <?php echo e($table->name); ?> (Location <?php echo e($table->location->name); ?> For
                                                        <?php echo e($table->guest_number); ?> Guests)
                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['table_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-sm text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="mt-4 p-2 d-flex justify-content-between">
                                        <a href="<?php echo e(route('reservations.step.one', $restaurant->id)); ?>"
                                            class="btn btn-danger rounded-pill px-4 py-2">Previous</a>
                                        <button type="submit" class="btn btn-primary rounded-pill px-4 py-2"
                                            value="noMenu">Reserve
                                            Table Only</button>
                                        <button type="submit" class="btn btn-warning rounded-pill px-4 py-2"
                                            value="withMenu">Reserve With
                                            Menu</button>
                                        
                                    </div>
                                </form>
                                <script>
                                    document.querySelector('#myForm').addEventListener('submit', function(event) {
                                        // Prevent the form from submitting
                                        event.preventDefault();

                                        // Get the action value of the button that was clicked
                                        const action = event.submitter.value;

                                        // Set the form action based on the button clicked
                                        if (action === 'noMenu') {
                                            this.action = "<?php echo e(route('reservations.store.step.two', $restaurant->id)); ?>";
                                        } else if (action === 'withMenu') {
                                            this.action = "<?php echo e(route('reservations.store.step.two.with.menu', $restaurant->id)); ?>";
                                        }

                                        // Submit the form
                                        this.submit();
                                    });
                                </script>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#myCarousel').carousel();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/customer/reservation/step-two.blade.php ENDPATH**/ ?>