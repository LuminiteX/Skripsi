<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CustomerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-4">
        <a href="<?php echo e(route('menu.index', ['restaurant' => $restaurant->id, 'reservation' => $reservation->id])); ?>"
            class="btn btn-sm btn-primary mt-5 mb-5">Return Back
            to
            menu</a>
    </div>
    <h2 class="my-4 mx-md-5 mx-xl-5 bottom-2">Menu Sort By <?php echo e($category->name); ?> Category</h2>
    <div class="container-fluid px-5 py-6 mx-auto" style="margin-bottom:150px">
        <div class="row row-cols-1 row-cols-lg-3 g-4">
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card h-100">
                        <img src="<?php echo e(Storage::url($menu->image)); ?>" alt="Image"
                            class="card-img-top h-50 object-fit-cover">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($menu->name); ?></h5>
                            <p class="card-text"><?php echo e($menu->description); ?></p>
                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center">
                            <span
                                class="text-success font-weight-bold"><?php echo e('Rp ' . number_format($menu->price, 0, ',', '.')); ?></span>
                            <a href="<?php echo e(route('menu.sort.by.menu.detail', ['menu' => $menu->id, 'reservation' => $reservation->id])); ?>"
                                class="btn btn-sm btn-primary">View
                                Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="d-flex justify-content-center mt-5 mb-3">
        <a href="<?php echo e(route('cart.list.detail', ['reservation' => $reservation->id])); ?>"
            class="btn btn-lg btn-warning">Manage Cart
            Details</a>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/customer/menus/sort-by-category.blade.php ENDPATH**/ ?>