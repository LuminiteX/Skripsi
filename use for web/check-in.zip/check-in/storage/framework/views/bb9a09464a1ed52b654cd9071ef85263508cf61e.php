<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CustomerLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-5">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-6 mb-4 mb-md-0">
                <img class="img-fluid shadow rounded"
                    src="https://cdn.pixabay.com/photo/2021/01/15/17/01/green-5919790__340.jpg" alt="img">
            </div>
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-body">
                        <h3 class="card-title text-primary mb-4">Make Reservation</h3>
                        <ul class="nav nav-pills mb-4" id="pills-tab" role="tablist">
                            <li class="nav-item w-100" role="presentation">
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 50%;" aria-valuenow="50"
                                        aria-valuemin="0" aria-valuemax="100">Step 1</div>
                                </div>
                            </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-step1" role="tabpanel"
                                aria-labelledby="pills-step1-tab">
                                <form method="POST" action="<?php echo e(route('reservations.store.step.one')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="restaurant_id" value="<?php echo e($restaurant->id); ?>">
                                    <div class="mb-3">
                                        <label for="guest_number" class="form-label">Guest Number</label>
                                        <input type="number" id="guest_number" name="guest_number"
                                            value="<?php echo e($reservation->guest_number ?? ''); ?>" class="form-control"
                                            required>
                                        <?php $__errorArgs = ['guest_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="res_date" class="form-label">Reservation Date</label>
                                        <input type="datetime-local" id="reservation_date" name="reservation_date"
                                            min="<?php echo e($min_date->format('Y-m-d\TH:i:s')); ?>"
                                            max="<?php echo e($max_date->format('Y-m-d\TH:i:s')); ?>"
                                            value="<?php echo e($reservation ? $reservation->reservation_date->format('Y-m-d\TH:i:s') : ''); ?>"
                                            class="form-control" required>
                                        <span class="form-text">Please choose the time between
                                            <?php echo e($formattedTimeOpening); ?>-<?php echo e($formattedTimeClosing); ?>.</span>
                                        <?php $__errorArgs = ['reservation_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary">Next</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php $__env->startPush('scripts'); ?>
        <script>
            document.querySelector('.hour-picker').addEventListener('click', function() {
                // Enable the input field when the user clicks on it
                this.querySelector('input[type="datetime-local"]').removeAttribute('disabled');
            });

            document.querySelector('.hour-picker').addEventListener('blur', function() {
                // Disable the input field again when the user leaves it
                this.querySelector('input[type="datetime-local"]').setAttribute('disabled', 'disabled');
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH C:\Users\kevin\Documents\GitHub\Skripsi\check-in\resources\views/customer/reservation/step-one.blade.php ENDPATH**/ ?>