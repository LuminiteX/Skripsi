<x-customer-layout>
<div class="container bg-white text-body">
    <div class="row text-center">
        <h2>Your Profile</h2>
    </div>
    <div class="row">
        <div class="col">
            <img src="storage/profile/pic.jpg" alt="profile" class="img-fluid">
        </div>
        <div class="col">
            <h4>Name</h4>
            <hr class="border-dark">
            <div class="row">
                <div class="col">
                    <h4>Email</h4>
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <h4>Phone Number</h4>
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <h4>Address</h4>
                    <hr>
                </div>
            </div>
        </div>
    </div>
</div>
</x-customer-layout>
